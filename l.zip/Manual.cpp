//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Manual.h"
//---------------------------------------------------------------------------
//#pragma link "Unit1"
#pragma link "FrameUnit"
#pragma link "Trayicon"
#pragma link "CSPIN"
#pragma resource "*.dfm"
TManualForm *ManualForm;

//---------------------------------------------------------------------------
__fastcall TManualForm::TManualForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------











