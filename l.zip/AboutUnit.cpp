//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "AboutUnit.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TAboutForm *AboutForm;
//---------------------------------------------------------------------------
__fastcall TAboutForm::TAboutForm(TComponent* Owner)
        : TForm(Owner)
{                      
}
//---------------------------------------------------------------------------
void __fastcall TAboutForm::BitBtn1Click(TObject *Sender)
{
AboutForm->Visible  = false;        
}
//---------------------------------------------------------------------------
