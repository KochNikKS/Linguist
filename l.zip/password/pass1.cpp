//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <fstream.h>
#include "pass1.h"
#include "Unit2.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
Form1->Hide();
Form2->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::MaskEdit1Change(TObject *Sender)
{
if (strlen(MaskEdit1->Text.c_str())>0)
{BitBtn1->Enabled = true;Timer1->Enabled = false;}
else {BitBtn1->Enabled = false;Timer1->Enabled = true;}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
if (Form1->Color != clRed)Form1->Color =clRed;
else Form1->Color = 12615680;        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormActivate(TObject *Sender)
{
Application->MessageBox("This program must be removed for maintenance of protection!\n��� ��������� ������ ���� ������� ��� ����������� ������!","Warning!",MB_OK|MB_ICONWARNING);
}
//---------------------------------------------------------------------------

