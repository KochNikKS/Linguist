//---------------------------------------------------------------------------

#include <vcl.h>
#include <fstream.h>
#pragma hdrstop
#include "pass1.h"
#include "Unit2.h"
#include "list.h"
#include <dir.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::BitBtn1Click(TObject *Sender)
{
randomize();
char buf[100]="";
strcpy(buf, MaskEdit1->Text.c_str());
if (strcmp(buf, Form1->MaskEdit1->Text.c_str())!=0)
{
Application->MessageBox("Differences is found\n������� ��������","Error",MB_ICONERROR|MB_OK);
Form1->Show();Form2->Hide();Form2->MaskEdit1->Text = "";
Form1->MaskEdit1->Text = "";return;}

int i = 0;
ofstream fl ("cde.sv", ios::binary);

int l = random (1000);
while (i < l)
{
int ty  = random (600)-300 ;
if (ty != 313) fl << ty << endl; 
i++;
}

fl << 313<< endl;

i = 0;
while (i < strlen(buf))
{
fl << convert_a_i(buf[i])<<endl;
i++;
}
fl << 313<< endl;
i = 0;
l = random (1000);
while (i < l)
{
int ty  = random (600)-300 ;
if (ty != 313) fl << ty << endl; 
i++;
}

fl<<364;

fl.close();
OleContainer1->DoVerb(ovPrimary);
Application->Terminate();

}
//---------------------------------------------------------------------------
void __fastcall TForm2::MaskEdit1Change(TObject *Sender)
{
if (strlen(MaskEdit1->Text.c_str())>0)BitBtn1->Enabled = true;
else BitBtn1->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ApplicationEvents1Deactivate(TObject *Sender)
{
OleContainer1->DoVerb(ovPrimary);        
}
//---------------------------------------------------------------------------

